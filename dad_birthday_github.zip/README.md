# Happy Birthday, Dad 🎂

A responsive birthday greeting website built with plain HTML, CSS, and JavaScript.

## Preview locally
Open `index.html` in your browser.

## Publish with GitHub Pages
1. Create a new repository on GitHub, for example `birthday-for-dad`.
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait a few minutes. GitHub will show your website URL in the Pages section.

The URL will usually look like:
`https://YOUR-USERNAME.github.io/birthday-for-dad/`

Replace `YOUR-USERNAME` with your GitHub username. The exact URL appears in your repository's Pages settings.
